package put.io.patterns.implement;

public class MonitorRunner {

    public static void main(String args[]){
        SystemMonitor2 monitor = new SystemMonitor2();

        SystemStateObserver infObserver = new SystemInfoObserver();
        SystemStateObserver gcObserver = new SystemGarbageCollectorObserver();
        SystemStateObserver scObserver = new SystemCoolerObserver();
        SystemStateObserver usbObserver = new USBDeviceObserver();
        monitor.addSystemStateObserver(infObserver);
        monitor.addSystemStateObserver(gcObserver);
        monitor.addSystemStateObserver(scObserver);
        monitor.addSystemStateObserver(usbObserver);


        while (true) {

            monitor.probe();

            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}
