package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver{
    @Override
    public void update(SystemMonitor2 monitor) {
        SystemState lastSystemState = monitor.getLastSystemState();

        System.out.println(String.format("USB devices: %d", lastSystemState.getUsbDevices()));

    }
}
